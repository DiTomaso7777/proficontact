# programare_drpciv
Unofficial DRPCIV API

De cele mai multe ori cea mai devreme data de programare pentru inmatriculari/permise poate fi chiar si peste 3 luni. Dar, din fericire, sunt programari care sunt anulate ori se adauga sloturi suplimentare.

How to use:

Pana cand sunteti dispus sa asteptati 

date_limit = datetime.datetime.strptime('2021-03-20 00:00:00','%Y-%m-%d %H:%M:%S').date()


Windows 10 alert

alerts.win10alert(date_limit,'INMATRICULARE','IS')

